<?php

namespace Viweb\SoumissionBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ViwebSoumissionBundle extends Bundle
{
}
